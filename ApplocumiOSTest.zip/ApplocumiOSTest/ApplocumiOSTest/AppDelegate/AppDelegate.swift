//
//  AppDelegate.swift
//  ApplocumiOSTest
//
//  Created by Paras Dharasanda on 05/01/21.
//

import UIKit
import IQKeyboardManagerSwift

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
   
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        IQKeyboardManager.shared.enable = true
        
        if let data = UserDefaults.standard.value(forKey: "UserData"){
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            let displayInfoViewController = storyBoard.instantiateViewController(withIdentifier: "DisplayInfoViewController")as! DisplayInfoViewController
            window?.rootViewController = displayInfoViewController
        }
        else{
            
        }
        return true
    }

    @available(iOS 13.0, *)
    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
      
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    @available(iOS 13.0, *)
    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
      
    }


}

