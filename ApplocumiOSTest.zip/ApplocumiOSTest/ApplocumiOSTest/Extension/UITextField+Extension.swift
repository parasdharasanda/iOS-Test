//
//  File.swift
//  ApplocumiOSTest
//
//  Created by Paras Dharasanda on 05/01/21.
//

import Foundation
import UIKit

extension UITextField {
    
    static func validateAll(textFields:[UITextField]) -> Bool {
        // Check each field for nil and not empty.
        for field in textFields {
            // Remove space and new lines while unwrapping.
            guard let fieldText = field.text?.trimmingCharacters(in: .whitespacesAndNewlines) else {
                return false
            }
            // Are there no other charaters?
            if (fieldText.isEmpty) {
                return false
            }
            
        }
        // All fields passed.
        return true
    }
}
