//
//  NewsViewController.swift
//  ApplocumiOSTest
//
//  Created by Paras Dharasanda on 05/01/21.
//

import UIKit
import Alamofire
import SDWebImage

class NewsViewController: UIViewController {

    @IBOutlet weak var NewsCollectionView: UICollectionView!
    
    var array_articles = [Articles]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setUI()
    }
    
}

extension NewsViewController{
    
    func setUI(){
        
        self.navigationItem.title = "News"
        
        self.NewsCollectionView.register(UINib(nibName: "NewsCell", bundle: nil), forCellWithReuseIdentifier: "NewsCell")
        self.NewsCollectionView.delegate = self
        self.NewsCollectionView.dataSource = self
        self.NewsCollectionView.reloadData()
        self.API_News()
    }
}
extension NewsViewController:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
   
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return array_articles.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let newsCell = collectionView.dequeueReusableCell(withReuseIdentifier: "NewsCell", for: indexPath)as! NewsCell
        
        if let imageUrl = URL(string: array_articles[indexPath.row].urlToImage){
            newsCell.imgNews.sd_imageIndicator = SDWebImageActivityIndicator.gray
            newsCell.imgNews.sd_setImage(with: imageUrl) { (image, error, cache, urls) in
                if (error != nil) {
                               // Failed to load image
                    newsCell.imgNews.image = UIImage(named: "logo")
                } else {
                               // Successful in loading image
                    newsCell.imgNews.image = image
                    newsCell.imgNews.contentMode = .scaleAspectFit
                }
            }
        }
        else{
            newsCell.imgNews.image = UIImage(imageLiteralResourceName: "logo")
        }
        
        newsCell.lblNewsTitle.text = array_articles[indexPath.row].title
        newsCell.lblNewsDescription.text = array_articles[indexPath.row].description
        
        newsCell.lblAuthor.text = array_articles[indexPath.row].author
        
       // label//.attributedText
         let underline = NSAttributedString(string: array_articles[indexPath.row].url, attributes: [.underlineStyle: NSUnderlineStyle.single.rawValue])
        newsCell.lblUrl.attributedText = underline
        newsCell.lblUrl.textColor = .systemBlue
        
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(selectOnLabel(_:)))
        newsCell.lblUrl.addGestureRecognizer(tap)
        newsCell.lblUrl.tag = indexPath.row
        newsCell.lblUrl.isUserInteractionEnabled = true
        
        let date = formattedDateFromString(dateString: array_articles[indexPath.row].publishedAt, withFormat: "MMM dd, yyyy")
        newsCell.lblPublished.text = date
        
        return newsCell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: NewsCollectionView.bounds.width, height: NewsCollectionView.bounds.height)
        
    }
    
}
extension NewsViewController{
    
    func formattedDateFromString(dateString: String, withFormat format: String) -> String? {

        let inputFormatter = DateFormatter()
       // inputFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX"

        inputFormatter.locale = Locale(identifier: "en_US_POSIX")
        inputFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
        
        if let date = inputFormatter.date(from: dateString) {

            let outputFormatter = DateFormatter()
          outputFormatter.dateFormat = format

            return outputFormatter.string(from: date)
        }

        return nil
    }
    
    @objc func selectOnLabel(_ gesture:UITapGestureRecognizer){
        let index = gesture.view?.tag
        
        if let url = URL(string: array_articles[index!].url) {
            if UIApplication.shared.canOpenURL(url) {
                if #available(iOS 10.0, *) {
                    UIApplication.shared.open(url, options: [:], completionHandler: nil)
                } else {
                    UIApplication.shared.openURL(url)
                }
            }
        }
    }
}
// API integration
extension NewsViewController{
    
    func API_News(){
        
        let url = "http://newsapi.org/v2/top-headlines?country=us&apiKey=2295e9dcf4924cc2b9796ebf43272c76"
        
        AF.request(url, method: .get).responseData { (response) in
            print(response)
            switch response.result{
                
            case .success(_):
                do{
                    let jsonDecoder = JSONDecoder()
                    let responseModel = try jsonDecoder.decode(News_Base.self, from: response.data!)
                    
                    self.array_articles.removeAll()
                    for list_articles in responseModel.articles{
                        self.array_articles.append(list_articles)
                    }
                    
                }
                catch{
                    print(error.localizedDescription)
                }
            break
            
            case .failure(_):
                
            break
            }
            
            self.NewsCollectionView.reloadData()
        }
    }
}
