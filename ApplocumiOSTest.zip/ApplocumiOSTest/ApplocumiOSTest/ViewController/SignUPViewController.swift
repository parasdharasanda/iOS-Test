//
//  SignUPViewController.swift
//  ApplocumiOSTest
//
//  Created by Paras Dharasanda on 05/01/21.
//

import UIKit
import ACFloatingTextfield_Swift

class SignUPViewController: UIViewController {

    @IBOutlet weak var txtFullName: ACFloatingTextfield!
    @IBOutlet weak var txtUserName: ACFloatingTextfield!
    @IBOutlet weak var txtEmail: ACFloatingTextfield!
    
    @IBOutlet weak var txtDateOfBirth: ACFloatingTextfield!
    @IBOutlet weak var txtMobileNumber: ACFloatingTextfield!
    @IBOutlet weak var txtPassword: ACFloatingTextfield!
    
    @IBOutlet weak var btnSignUP: UIButton!
    
    let datePicker = UIDatePicker()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setUI()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnClickOnSignUP(_ sender: Any) {
        
        if validate{
            
            let data = ["FullName":txtFullName.text!,
                        "UserName":txtUserName.text!,
                        "Email":txtEmail.text!,
                        "DateOfBirth":txtDateOfBirth.text!,
                        "MobilNumber":txtMobileNumber.text!,
                        "Password":txtPassword.text!]
            
            UserDefaults.standard.set(data, forKey: "UserData")
            
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            let displayInfoViewController = storyBoard.instantiateViewController(withIdentifier: "DisplayInfoViewController")as! DisplayInfoViewController
            self.navigationController?.pushViewController(displayInfoViewController, animated: true)
        }
    }
    
}
extension SignUPViewController{
    
    
    func setUI(){
        
        self.txtFullName.delegate = self
        self.txtUserName.delegate = self
        self.txtEmail.delegate = self
        self.txtDateOfBirth.delegate = self
        self.txtMobileNumber.delegate = self
        self.txtPassword.delegate = self
        
        self.txtFullName.font = UIFont.systemFontOfSize(size: 18.0)
        self.txtUserName.font = UIFont.systemFontOfSize(size: 18.0)
        self.txtEmail.font = UIFont.systemFontOfSize(size: 18.0)
        self.txtDateOfBirth.font = UIFont.systemFontOfSize(size: 18.0)
        self.txtMobileNumber.font = UIFont.systemFontOfSize(size: 18.0)
        self.txtPassword.font = UIFont.systemFontOfSize(size: 18.0)
    }
    var validate:Bool{
        
        if !UITextField.validateAll(textFields: [txtFullName]){
            
            txtFullName.selectedPlaceHolderColor = .errorColor
            txtFullName.selectedLineColor = .errorColor
            txtFullName.showErrorWithText(errorText: "Please enter full name!")
            return false
        }
        else if !UITextField.validateAll(textFields: [txtUserName]){
            txtUserName.selectedLineColor = .errorColor
            txtUserName.selectedPlaceHolderColor = .errorColor
            txtUserName.showErrorWithText(errorText: "Please enter username!")
            return false
        }
        else if !UITextField.validateAll(textFields: [txtEmail]){
            txtEmail.selectedLineColor = .errorColor
            txtEmail.selectedPlaceHolderColor = .errorColor
            txtEmail.showErrorWithText(errorText: "Please enter email!")
            return false
        }
        else if !validateEmail(enteredEmail: txtEmail.text!){
            txtEmail.selectedLineColor = .errorColor
            txtEmail.selectedPlaceHolderColor = .errorColor
            txtEmail.showErrorWithText(errorText: "Please enter valid email!")
            return false
        }
        else if !UITextField.validateAll(textFields: [txtDateOfBirth]){
            txtDateOfBirth.selectedLineColor = .errorColor
            txtDateOfBirth.selectedPlaceHolderColor = .errorColor
            txtDateOfBirth.showErrorWithText(errorText: "Please enter date of birth!")
            return false
        }
        else if !UITextField.validateAll(textFields: [txtMobileNumber]){
            txtMobileNumber.selectedLineColor = .errorColor
            txtMobileNumber.selectedPlaceHolderColor = .errorColor
            txtMobileNumber.showErrorWithText(errorText: "Please enter mobile number!")
            return false
        }
        else if ((txtMobileNumber.text?.count)! < 10 && (txtMobileNumber.text?.count)! > 0){
            txtMobileNumber.selectedLineColor = .errorColor
            txtMobileNumber.selectedPlaceHolderColor = .errorColor
            txtMobileNumber.showErrorWithText(errorText: "Please enter 10 digit mobile number!")
            return false
        }
        else if !UITextField.validateAll(textFields: [txtPassword]){
            txtPassword.selectedLineColor = .errorColor
            txtPassword.selectedPlaceHolderColor = .errorColor
            txtPassword.showErrorWithText(errorText: "Please enter password!")
            return false
        }
        else if !isValidPassword(text: txtPassword.text!){
            txtPassword.selectedLineColor = .errorColor
            txtPassword.selectedPlaceHolderColor = .errorColor
            txtPassword.showErrorWithText(errorText: "Please enter valid password")
        }
        
        return true
    }
}
extension SignUPViewController:UITextFieldDelegate{
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if textField == txtMobileNumber{
            
            //txtMobileNumber.selectedPlaceHolderColor = .primary
            //txtMobileNumber.selectedLineColor = .primary
            guard let text = self.txtMobileNumber.text else{
                return true
            }
            let newLength = text.count + string.count - range.length
            return newLength <= 10
        }
        else if textField == txtFullName{
            
           // txtPassword.selectedPlaceHolderColor = .primary
            //txtPassword.selectedLineColor = .primary
            guard let text = self.txtPassword.text else{
                return true
            }
            let newLength = text.count + string.count - range.length
            return newLength <= 50
        }
        else if textField == txtUserName{
            
           // txtPassword.selectedPlaceHolderColor = .primary
            //txtPassword.selectedLineColor = .primary
            guard let text = self.txtPassword.text else{
                return true
            }
            let newLength = text.count + string.count - range.length
            return newLength <= 20
        }
        return true
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if textField == txtFullName{
            //txtMobileNumber.selectedLineColor = .primary
            //txtMobileNumber.selectedPlaceHolderColor = .primary
            return true
        }
        else if textField == txtUserName{
            //txtMobileNumber.selectedLineColor = .primary
            //txtMobileNumber.selectedPlaceHolderColor = .primary
            return true
        }
        else if textField == txtEmail{
            //txtMobileNumber.selectedLineColor = .primary
            //txtMobileNumber.selectedPlaceHolderColor = .primary
            return true
        }
        else if textField == txtDateOfBirth{
            //txtMobileNumber.selectedLineColor = .primary
            //txtMobileNumber.selectedPlaceHolderColor = .primary
            showDatePicker()
            return true
        }
        else if textField == txtMobileNumber{
            //txtMobileNumber.selectedLineColor = .primary
            //txtMobileNumber.selectedPlaceHolderColor = .primary
            return true
        }
        else if textField == txtPassword{
            //txtMobileNumber.selectedLineColor = .primary
            //txtMobileNumber.selectedPlaceHolderColor = .primary
            return true
        }
        return false
    }
    
    
}
extension SignUPViewController{
    
    func isValidPassword(text:String) -> Bool {
        let password = text.trimmingCharacters(in: CharacterSet.whitespaces)
        let passwordRegx = "^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&<>*~:`-]).{8,}$"
        let passwordCheck = NSPredicate(format: "SELF MATCHES %@",passwordRegx)
        return passwordCheck.evaluate(with: password)

    }
    
    func showDatePicker(){
        //Formate Date
        datePicker.datePickerMode = .date
        datePicker.set18YearValidation()
        //ToolBar
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(donedatePicker));
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelDatePicker));
        
        toolbar.setItems([doneButton,spaceButton,cancelButton], animated: false)
        
        txtDateOfBirth.inputAccessoryView = toolbar
        txtDateOfBirth.inputView = datePicker
        
    }
    
    @objc func donedatePicker(){
        
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        txtDateOfBirth.text = formatter.string(from: datePicker.date)
        self.view.endEditing(true)
    }
    
    @objc func cancelDatePicker(){
        self.view.endEditing(true)
    }
    
    func validateEmail(enteredEmail:String) -> Bool {

        let emailFormat = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format:"SELF MATCHES %@", emailFormat)
        return emailPredicate.evaluate(with: enteredEmail)

    }
}
