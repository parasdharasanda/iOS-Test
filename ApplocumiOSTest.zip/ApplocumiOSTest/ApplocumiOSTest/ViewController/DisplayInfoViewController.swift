//
//  DisplayInfoViewController.swift
//  ApplocumiOSTest
//
//  Created by Paras Dharasanda on 05/01/21.
//

import UIKit

class DisplayInfoViewController: UIViewController {

    @IBOutlet weak var lblFullName: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblMobileNumber: UILabel!
    @IBOutlet weak var lblDateOfBirth: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setUI()
    }

}
extension DisplayInfoViewController{
    
    func setUI(){
        
        self.navigationItem.hidesBackButton = true
        self.navigationItem.title = "User Info"
        let logoutBarButtonItem = UIBarButtonItem(title: "Logout", style: .done, target: self, action: #selector(clickOnLogout))
        self.navigationItem.leftBarButtonItem  = logoutBarButtonItem
        
        let newsBarButtonItem = UIBarButtonItem(title: "News", style: .done, target: self, action: #selector(clickOnNews))
        self.navigationItem.rightBarButtonItem  = newsBarButtonItem
        
        if let data = UserDefaults.standard.value(forKey: "UserData")as? [String: String]{
            print(data)
            
            self.lblEmail.text = data["Email"]
            self.lblFullName.text = data["FullName"]
            self.lblMobileNumber.text = data["MobilNumber"]
            self.lblDateOfBirth.text = data["DateOfBirth"]
        }
        else{
            self.lblEmail.text = ""
            self.lblFullName.text = ""
            self.lblMobileNumber.text = ""
            self.lblDateOfBirth.text = ""
        }
    }
}
extension DisplayInfoViewController{
    
    @objc func clickOnLogout(){
        UserDefaults.standard.removeObject(forKey: "UserData")
    }
    
    @objc func clickOnNews(){
        
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let newsViewController = storyBoard.instantiateViewController(withIdentifier: "NewsViewController")as! NewsViewController
        self.navigationController?.pushViewController(newsViewController, animated: true)
    }
}
