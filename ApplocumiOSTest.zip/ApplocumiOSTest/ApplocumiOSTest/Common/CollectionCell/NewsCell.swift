//
//  NewsCell.swift
//  ApplocumiOSTest
//
//  Created by Paras Dharasanda on 05/01/21.
//

import UIKit

class NewsCell: UICollectionViewCell {

    @IBOutlet weak var imgNews: UIImageView!
    @IBOutlet weak var lblNewsTitle: UILabel!
    @IBOutlet weak var lblNewsDescription: UILabel!
    
    @IBOutlet weak var lblUrl: UILabel!
    
    @IBOutlet weak var lblPublished: UILabel!
    @IBOutlet weak var lblAuthor: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
